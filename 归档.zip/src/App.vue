<template>
  <div id="app">
    <router-view/>
  </div>
</template>

<script>
export default {
  name: 'App'
}
</script>
<style lang="scss">
@import '~@/../static/css/normalize.css';
@import '~@/../static/css/app.scss';
</style>